﻿// Server.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include "winsock2.h"
#include <string.h>
#include <time.h>

using namespace std;

#pragma comment(lib,"ws2_32.lib")
struct USER {
	char username[50];
	char password[50];
};


struct USER list[50];

const char *header = "HTTP/1.1 200 OK\nContent-Type: text/html\n\n";
int main()
{
	int ret;
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) == SOCKET_ERROR) {
		cout << "Error: " << WSAGetLastError() << endl;
		return 1;
	}
	else {
		cout << "Khoi dong thanh cong!" << endl;
	}

	SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (listener == INVALID_SOCKET) {
		cout << "Loi khoi tao Socket: " << WSAGetLastError() << endl;
	}
	else {
		cout << "Khoi tao Socket thanh cong" << endl;
	}

	SOCKADDR_IN addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(9000);

	int iResult = bind(listener, (SOCKADDR *)&addr, sizeof(addr));
	char sendbuf[256];
	if (iResult == SOCKET_ERROR)
	{
		cout << "Khong ket buoc duoc Socket va Port!" << WSAGetLastError() << endl;
		return 1;
	}

	iResult = listen(listener, 5);
	if (iResult == SOCKET_ERROR)
	{
		cout << "Khong the lang nghe ket noi!" << WSAGetLastError() << endl;
		return 1;
	}
	else {
		cout << "Dang lang nghe ket noi..." << endl;
	}
	fd_set fdread;
	timeval tv;
	tv.tv_sec = 10;
	tv.tv_usec = 0;
	SOCKET clients[64];
	int numClients = 0;
	while (true)
	{
		FD_ZERO(&fdread);
		FD_SET(listener, &fdread);
		for (int i = 0; i < numClients; i++)
			FD_SET(clients[i], &fdread);

		ret = select(0, &fdread, NULL, NULL, NULL);
		if (ret == SOCKET_ERROR)
		{
			break;
		}
		else if (ret == 0)
		{
			printf("Timed out!\n");
		}
		else if (ret > 0)
		{
			if (FD_ISSET(listener, &fdread))
			{
				time_t hientai;
				struct tm ts;
				char buftime[80];
				//get current time
				time(&hientai);
				//format time,"ddd yyyy-mm-dd hh:mm:ss zzz"
				ts = *localtime(&hientai);
				strftime(buftime, sizeof(buftime), "%a %Y-%m-%d %H:%M:%S %Z", &ts);
				SOCKADDR_IN clientAddr;
				int clientAdderLen = sizeof(clientAddr);
				SOCKET client = accept(listener, (SOCKADDR *)&clientAddr, &clientAdderLen);
				printf("New client accepted: %d\n", client);
				FILE *f = fopen("history.txt", "a");
				fseek(f, 0, SEEK_END);
				fprintf(f, "\n IP %s KET NOI VAO %s\n", inet_ntoa(clientAddr.sin_addr), buftime);
				fclose(f);

				clients[numClients] = client;
				numClients++;
			}
			for (int i = 0; i < numClients; i++)
				if (FD_ISSET(clients[i], &fdread))
				{
					char buf[1024];
					char path[64], tmp[64];
					ret = recv(clients[i], buf, sizeof(buf), 0);
					buf[ret] = '\0';
					printf("%s\n", buf);
					sscanf(buf, "%s %s", path, tmp);

					if (strncmp(buf + 4, "/hello", 6) == 0)
					{
						//Tra ket qua cho trinh duyet
						send(clients[i], header, strlen(header), 0);
						char sendbuf[256];
						FILE *f = fopen("hello.html", "rb");
						fgets(sendbuf, 255, (FILE *)f);
						while (1) {
							ret = fread(sendbuf, 1, sizeof(sendbuf), f);
							if (ret > 0) {
								send(clients[i], sendbuf, ret, 0);
							}
							else {
								break;
							}
						}
						fclose(f);
						break;

					}
					else if (strncmp(buf + 4, "/dangky", 7) == 0) {
						send(clients[i], header, strlen(header), 0);
						FILE *f = fopen("signup.html", "rb");
						fgets(sendbuf, 255, (FILE *)f);
						while (1)
						{
							ret = fread(sendbuf, 1, sizeof(sendbuf), f);

							if (ret > 0)
								send(clients[i], sendbuf, ret, 0);
							else
								break;
						}

						fclose(f);
					}
					else if (strncmp(buf + 5, "/signup", 7) == 0) {

#pragma region getJSON-Data
						printf("%s", buf);
						int k;
						for (k = strlen(buf); k > 0; k--) {
							if (buf[k] == '\n') {
								break;
							}
						}
						char json[128];
						int m = 0;
						for (int h = k + 1; h < strlen(buf); h++) {
							json[m] = buf[h];
							m++;
						}
						json[m] = 0;


#pragma endregion
#pragma region seperateData
						for (int h = 0; h < strlen(json); h++) {
							if (json[h] == '&' || json[h] == '=') {
								json[h] = ' ';
							}
						}

						char name[64], pass[64];
						sscanf(json, "%s %s", name, pass);
						const char *kq = "sucess";
						FILE *fp = fopen("list.txt", "a+");
						fseek(fp, 0, SEEK_END);
						ret = ftell(fp);
						if (fp == 0) {
							fprintf(fp, "%s %s", name, pass);
							send(clients[i], header, strlen(header), 0);
						}
						else {
							int found = 0;
							char buffile[1024];
							fseek(fp, 0, SEEK_SET);
							while (fgets(buffile, sizeof(buffile), fp))
							{
								if (buffile[strlen(buffile) - 1] == '\n')
									buffile[ret - 1] = 0;
								if (strcmp(buffile, buf) == 0)
								{
									found = 1;
									break;
								}

							}

							if (found == 1) {
								send(clients[i], header, strlen(header), 0);
								const char *kq1 = "false";
								send(clients[i], kq1, strlen(kq1), 0);
							}
							if (found == 0) {
								send(clients[i], header, strlen(header), 0);
								send(clients[i], kq, strlen(kq), 0);
								fseek(fp, 0, SEEK_END);
								fprintf(fp, "%s %s\n", name, pass);
							}
						}
						fclose(fp);


#pragma endregion
					}
					else if (strncmp(buf + 4, "/dangnhap", 9) == 0)
					{
						char sendbuf[256];
						FILE *f = fopen("signin.txt", "rb");
						fgets(sendbuf, 255, (FILE *)f);
						while (1)
						{
							ret = fread(sendbuf, 1, sizeof(sendbuf), f);
							if (ret > 0)
								send(clients[1], sendbuf, ret, 0);
							else
								break;
						}
						fclose(f);
					}
					else if (strncmp(buf + 5, "/signin", 7) == 0) {

#pragma region getJSON-Data
						printf("%s", buf);
						int k;
						for (k = strlen(buf); k > 0; k--) {
							if (buf[k] == '\n') {
								break;
							}
						}
						char json[128];
						int m = 0;
						for (int h = k + 1; h < strlen(buf); h++) {
							json[m] = buf[h];
							m++;
						}
						json[m] = 0;


#pragma endregion
#pragma region seperateData
						for (int h = 0; h < strlen(json); h++) {
							if (json[h] == '&' || json[h] == '=') {
								json[h] = ' ';
							}
						}
						char name[64], pass[64];
						sscanf(json, "%s %s", name, pass);
						FILE *fp = fopen("list.txt", "a+");
						int found = 0;
						char buffile[1024];
						while (fgets(buffile, sizeof(buffile), fp))
						{
							if (buffile[strlen(buffile) - 1] == '\n')
								buffile[ret - 1] = 0;
							if (strcmp(buffile, buf) == 0)
							{
								found = 1;
								break;
							}

						}
						if (found == 1) {
						}
						else if (found == 0) {

						}
#pragma endregion
						closesocket(clients[i]);

					}
				}

		}
		return 0;
	}
}
	
	